$(document).ready(function(){
	$('#copyRightYear').text((new Date).getFullYear());
});